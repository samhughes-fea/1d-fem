from dataclasses import dataclass, field
from typing import List
from external_forces.blade_external_force_row import BladeExternalForceRow

@dataclass
class BladeExternalForceBin:
    rows: List[BladeExternalForceRow] = field(default_factory=list)

    def get_by_tsr(self, tsr: str) -> BladeExternalForceRow:
        for row in self.rows:
            if row.tsr == tsr:
                return row
        raise ValueError(f"No TSR result found for: {tsr}")
