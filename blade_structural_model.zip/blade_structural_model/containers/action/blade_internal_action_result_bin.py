from dataclasses import dataclass, field
from typing import List
from containers.blade_internal_action_result_row import BladeInternalActionResultRow

@dataclass
class BladeInternalActionResultBin:
    rows: List[BladeInternalActionResultRow] = field(default_factory=list)

    def get_by_tsr(self, tsr: str) -> BladeInternalActionResultRow:
        for row in self.rows:
            if row.tsr == tsr:
                return row
        raise ValueError(f"No TSR result found for: {tsr}")
