from dataclasses import dataclass, field
from typing import List
from rigidity.blade_rigidity_row import BladeRigidityRow

@dataclass
class BladeRigidityBin:
    rows: List[BladeRigidityRow] = field(default_factory=list)

    def get_by_tsr(self, tsr: str) -> BladeRigidityRow:
        for row in self.rows:
            if row.tsr == tsr:
                return row
        raise ValueError(f"No TSR result found for: {tsr}")
